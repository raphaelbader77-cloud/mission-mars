# Gemeinsam entwickeln und auf GitHub Pages veröffentlichen

## Ein Repository für beide Personen

Eine Person erstellt auf GitHub ein leeres Repository, beispielsweise `mission-mars`, und lädt den Teampartner unter **Settings → Collaborators** ein. Für die gemeinsame Entwicklung den Quellordner des entpackten ZIP verwenden. Im Projektordner befinden sich bereits `.gitignore` und der Workflow unter `.github/workflows/pages.yml`.

```sh
git init -b main
git add .
git commit -m "Add Mission Mars Chapter 1"
git remote add origin https://github.com/EUER-KONTO/mission-mars.git
git push -u origin main
```

`EUER-KONTO` und gegebenenfalls den Repositorynamen durch eure Werte ersetzen. Der Partner klont das Repository, installiert Node.js 24 und führt `npm ci` aus. Generierte Builds, installierte Pakete und lokale Spielstände gehören nicht in Git.

## Ein Spielstand ist kein Git-Commit

Git synchronisiert Quellcode und Grafiken. Jeder Spieler behält seine eigene lokale PostgreSQL-Datenbank. Zum gemeinsamen Testen desselben Kapitelfortschritts kann eine Person den JSON-Spielstand exportieren und der anderen geben.

## Kleine gemeinsame Änderungen

1. Für eine Aufgabe ein kurzes Issue mit Lernziel und einem konkreten Testfall anlegen.
2. Mit `git switch -c feature/mission-materials` einen eigenen Branch beginnen.
3. Eine Person modelliert die Python-Regel und Grenzfälle, die andere schreibt Dialog, Beispiel und Szene. Beim nächsten Auftrag die Rollen tauschen.
4. Vor dem Pull Request `npm test`, `npm run build` und `npm run test:browser` ausführen. Beim ersten Mal Chromium mit `npx playwright install chromium` installieren.
5. Im Pull Request eine korrekte Alternative und eine falsche Lösung notieren. Der Partner spielt die Mission, liest den Diff und prüft, ob er die Änderung erklären kann.
6. Nach dem Merge lokal mit `git switch main` und `git pull` aktualisieren.

## GitHub Pages einschalten

1. Ein Repository mit verfügbarer Pages-Funktion verwenden. Für das spätere öffentliche Schulprojekt eignet sich ein öffentliches Repository.
2. Unter **Settings → Pages → Build and deployment → Source** die Option **GitHub Actions** wählen.
3. Im Register **Actions** den Workflow **Mission Mars on GitHub Pages** öffnen. Er läuft bei Pushes auf `main`. Nach dem erstmaligen Einschalten kann er mit **Run workflow** erneut gestartet werden.
4. Der Build installiert aus dem Lockfile, prüft Python und SQL, baut das Spiel und führt die Browsertests aus. Bei einem Pull Request endet der Ablauf nach den Prüfungen. Für `main` lädt der Workflow `dist/` hoch und veröffentlicht das Ergebnis.
5. Die echte URL steht in der Deployment-Ausgabe und unter **Settings → Pages**. Typisch ist `https://EUER-KONTO.github.io/mission-mars/`. Im privaten Fenster **New Game** starten, eine Abfrage ausführen und neu laden.

Falls der erste Deployment-Job scheitert, zuerst prüfen, ob Pages für dieses Repository aktiviert ist, ob der Branch tatsächlich `main` heisst und ob GitHub Actions laufen darf. Bei einer Umbenennung des Repositorys kann sich der Speicherort des lokalen Spielstands ändern. Vor dem Wechsel exportieren.

Der Build verwendet relative Pfade. Ein anderer statischer Hoster muss lediglich den Inhalt von `dist/` über HTTPS unter einem stabilen Pfad ausliefern, mit JavaScript-Modulen, korrektem WASM-MIME-Typ und Zugriff auf alle Unterordner. Ein Python-Backend oder zentraler PostgreSQL-Dienst ist dafür entbehrlich.

[GitHub-Dokumentation für Pages-Workflows](https://docs.github.com/en/pages/getting-started-with-github-pages/using-custom-workflows-with-github-pages) · [Vite-Dokumentation zu statischem Hosting](https://vite.dev/guide/static-deploy.html)

