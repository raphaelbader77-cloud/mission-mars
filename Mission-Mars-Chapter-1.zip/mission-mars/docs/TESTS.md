# Testprotokoll · Kapitel 1

## Durchgeführte Prüfungen

| Bereich | Durchführung | Beobachtung |
|---|---|---|
| Machbarkeit | Separater Browserprototyp, Erststart und Reload | Python-Klasse instanziiert; echter SQLSTATE 42601 nach absichtlich falschem SQL; Folgeabfrage erfolgreich; zwei zusammen gespeicherte Zähler blieben nach Reload konsistent. |
| Python-Modell | Vier unittest-Tests | Sperren, Importvalidierung, Reihenfolge, NULL, Typen, Dubletten und Inhaltsreferenzen bestanden. |
| SQL und Laufzeitgrenze | Node-Test mit echtem Pyodide und PGlite | Alle 13 Untertests bestanden. Neun SQL-Missionen wurden jeweils mit neun Eingaben geprüft. |
| Spielbarkeit | Interaktiver Chromium-Durchlauf gegen den statisch ausgelieferten Produktionsbuild unter `/mission-mars/` | Briefing, Orientierung, Felderkundung, Hilfe, SQL Guide, neun SQL-Aufgaben und Abschlussbildschirm mit allen vier Rollen erreicht. |
| Sicherung und Wiederaufnahme | Separater automatisierter Chromium-Durchlauf | Pilot auf James Wilson gewechselt, Ton ausgeschaltet, JSON heruntergeladen, Fortschritt zurückgesetzt und dieselbe Datei importiert. Nach Reload erschienen derselbe Pilot und ausgeschalteter Ton. |
| Wiederholung | Abgeschlossene Mission über Mission directory geöffnet | Der Editor öffnete die gewählte Leseaufgabe erneut, auch nach Reload und Continue. Ein ungültiger JSON-Import wurde abgewiesen; der vorhandene Spielstand blieb erhalten. |
| Darstellung | Desktop visuell geprüft; Menü zusätzlich mit 390 und 768 CSS-Pixeln Breite gerendert | Hauptmenü und durchsuchbarer Guide waren bedienbar. Die Dokumentbreite überschritt die jeweilige Bildschirmbreite nicht. Auch der SQL-Editor wurde bei 390 Pixeln geöffnet und auf horizontalen Seitenüberlauf geprüft. |
| Build | `npm run build` | Vite erzeugte zwei statische HTML-Einstiege, lokale WASM-Dateien, Editor- und Worker-Bundles sowie die Assets. |

Die neun Prüfungen je SQL-Mission umfassen eine leere Eingabe, einen Syntaxfehler, einen Schreibversuch, eine falsche Spalte im Ergebnis, eine unbekannte Spalte, ein inhaltlich falsches Ergebnis, die Referenzlösung, eine gleichwertige Alternative und abweichende Formatierung. Zusätzliche Prüfungen decken fest codierte IDs, Mehrfachanweisungen, Funktionsaufrufe und den Zugriff auf andere Tabellen ab. Für die erste Mission prüft ein eigener Test die Tabelleninteraktion.

Der Browsertest verwendet unter anderem die normale Editor-Tastenkombination, alle drei Hilfestufen, die echte Download-Datei und das Datei-Eingabefeld für den Import. Synthetische Klicks prüfen den SFX-Schalter und seinen gespeicherten Zustand. Die akustische Qualität auf physischen Lautsprechern wurde nicht gemessen.

## Wiederholen

```sh
npm ci
npm test
npm run build
npx playwright install chromium
npm run test:browser
node prototype/node-probe.mjs
```

Für einen bereits installierten Chromium-Browser kann `MARS_TEST_CHROMIUM` auf die ausführbare Datei zeigen. Die Testläufe behalten keine privaten Spielerdaten. Für eine manuelle Prüfung im Unterverzeichnis den gebauten Ordner als `mission-mars/` unter einem lokalen statischen Server ausliefern.

Die Browser-Messwerte stehen in [Prototyp und Messbedingungen](../prototype/README.md). Statische Unterverzeichnis-Auslieferung wurde geprüft. Eine echte Veröffentlichung in eurem GitHub-Konto sowie Durchläufe auf physischer Android- oder iOS-Hardware, Safari und Firefox stehen aus.

