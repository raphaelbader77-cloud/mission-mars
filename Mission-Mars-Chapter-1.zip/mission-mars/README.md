# Mission Mars

Ein englischsprachiges SQL-Adventure für den Informatikunterricht. Im Jahr 2084 hat die Marsstation Outpost Nine den Kontakt zur Erde verloren. Am ARES Space Center untersucht der Commander die Flugakten, prüft medizinische Freigaben und stellt ein vierköpfiges Team zusammen. Kapitel 1 enthält eine interaktive Einführung und neun Aufgaben mit echten PostgreSQL-Abfragen.

## Sofort spielen

1. Das vollständige ZIP entpacken und ein Terminal im Ordner `mission-mars` öffnen.
2. Unter Windows `py -3 play.py` ausführen, auf macOS oder Linux `python3 play.py`. Voraussetzung ist Python 3. Der Browser öffnet sich auf `http://127.0.0.1:8084/`.
3. **New Game** wählen. Nach Morgans Briefing zeigt NOVA, wie sich eine Person und ein Attribut in der Tabelle finden lassen.
4. Für spätere Sitzungen denselben Browser und dieselbe Adresse verwenden. **Continue** setzt den lokalen Flug fort. Mit **Ctrl+C** endet der lokale Dateiserver.

Der Ordner `dist/` im Download enthält das vollständige Spiel samt WebAssembly, Schriften und Bildern. Zum Spielen dieses Builds wird keine Paketinstallation benötigt. Beim Doppelklick auf `index.html` blockieren Browser Teile des Modulzugriffs. Der kleine lokale Starter liefert die Dateien über HTTP aus. Nach einer Veröffentlichung erledigt das der statische Hoster.

## Bedienung

| Funktion | Bedienung |
|---|---|
| SQL ausführen | **Run Query** oder **Ctrl+Enter** bzw. **⌘+Enter** |
| Leeren oder neu beginnen | **Clear** leert den Editor. **Reset Query** setzt zusätzlich Hinweise und Rückmeldung der Aufgabe zurück. |
| Hinweise | Nacheinander Konzept, Syntax und vollständige Beispielantwort einblenden |
| Tabelle untersuchen | **Inspect table** zeigt Schema, Schlüssel, Feldtypen und alle 13 Datensätze |
| Themen nachschlagen | **SQL Guide** durchsucht Erklärungen, Beispiele und typische Fehler |
| Aufgabe wiederholen | **Chapter Selection** bzw. **Mission directory**, danach eine abgeschlossene Aufgabe auswählen |
| Besatzung | Nach Mission 10 sind alle vier Rollen besetzt. Der Pilot lässt sich im Abschlussbildschirm wechseln. |
| Sicherung | **Settings → Export Save** speichert JSON. **Import Save** prüft die Datei vor Übernahme. |
| Ton und Bewegung | Im Einstellungsfenster schaltbar. Die Systemeinstellung für reduzierte Bewegung hat Vorrang. |

## Entwickeln und testen

Voraussetzungen für die Entwicklung sind Node.js 24, npm, Git und Python 3.10 oder neuer. Die erste Installation braucht Internet. Die Versionen sind im Lockfile fixiert.

```sh
npm ci
npm run dev
```

Den von Vite ausgegebenen Link öffnen. Änderungen in `src/` und `content/` erscheinen in der Entwicklungsansicht. Der Start kopiert die benötigten Laufzeitdateien aus den installierten npm-Paketen nach `public/vendor/`.

```sh
npm test
npm run build
npx playwright install chromium
npm run test:browser
npm run preview
```

Unter Windows mit dem Python-Launcher lassen sich die beiden Teile von `npm test` auch einzeln ausführen: `py -3 -m unittest discover -s tests` und `node --test tests/queries.test.mjs`. Die Browsertests starten die gebaute Anwendung auf Testport 4190 und verwenden frische Browserprofile. Der Machbarkeitstest ist unter `prototype.html` erreichbar. Er schreibt in eine eigene Testdatenbank.

## Verzeichnis und Zuständigkeiten

| Pfad | Inhalt |
|---|---|
| `src/python/game.py` | Spielaktionen, Freischaltungen, Crew-Auswahl und Zustandsansicht |
| `src/python/domain.py` | Chapter, Mission, Orientation, Character, GameState, SolutionValidator |
| `src/python/bridge.py` | Python-Einstieg für asynchrone SQL-Anfragen und Spielbefehle |
| `src/js/runtime*.js` | Nachrichten zwischen Oberfläche und Worker, Start der WebAssembly-Laufzeiten |
| `src/js/database.js`, `query-policy.js` | PostgreSQL-Schema, Lesezugriff, SQL-Analyse und Speicherung |
| `src/js/editor.js`, `screens.js`, `panels.js`, `main.js` | SQL-Editor, Szenen, Dialogfenster und Eingaben |
| `content/` | Missionen, Lehrtexte, Kapitelplan und Astronautendaten in JSON |
| `public/art/`, `tools/generate_art.py` | Originalgrafiken und ihr optionaler Generator mit Pillow und NumPy |
| `src/js/ui-kit.js` | Pixel-Icons, Tabellen und per Web Audio erzeugte Klangeffekte |
| `tests/`, `prototype/` | Automatisierte Tests, Machbarkeitsversuch und Messungen |
| `docs/`, `.github/workflows/pages.yml` | Architektur, Zusammenarbeit und Veröffentlichung |

## Wie SQL bewertet wird

Python erhält die sichtbare Abfrage, fordert über eine asynchrone JavaScript-Funktion zwei Ergebnispaare von PGlite an und vergleicht sie. Pro Datensatz laufen Kandidatenabfrage und Referenzabfrage. Der Vergleich berücksichtigt die ausgewählten Quellspalten, PostgreSQL-Typen, Werte und Häufigkeiten. Aliasse und eine andere Zeilenreihenfolge sind in Kapitel 1 zulässig. Die DISTINCT-Mission prüft zusätzlich das entsprechende Merkmal im Syntaxbaum. In der zweiten Datenmenge sind Kandidaten und Grenzfälle anders kombiniert.

Ein Beispiel aus Mission 7 zeigt den Unterschied zwischen einer passenden Person und einer passenden Regel. Ines Costa bringt neun Jahre als Ingenieurin mit und ist bereits anderweitig eingeteilt. Eine Abfrage ohne Verfügbarkeitsbedingung findet sie fälschlich. Das Spiel lässt die Abfrage laufen, zeigt das Ergebnis und erklärt die Abweichung.

## Eine Mission ergänzen

1. In `content/missions.json` eine Definition mit einer fortlaufenden ID anlegen. `guide` verweist auf einen Eintrag in `content/guide.json`, `speaker` auf einen registrierten Charakter, `scene` auf eine vorhandene Grafik.
2. Ziel, Dialog, Referenzabfrage, drei Hinweise und eine Erfolgsmeldung ergänzen. Bei reinen Leseaufgaben übernimmt `Mission` die bestehende Prüfung. `ordered` aktivieren, wenn die Reihenfolge ausdrücklich Teil der Aufgabe ist.
3. Für neue Lernziele einen Guide-Eintrag, eine alternative Lösung und einen bewusst falschen Grenzfall ergänzen. Die Tests für die ursprünglichen zehn Aufgaben dokumentieren die bisherige Reihenfolge.
4. Beim Erweitern des veröffentlichten Kapitels auch Abschlussposition, Crew-Belohnung, Nummerierung und bestehende Spielstände berücksichtigen. Für Kapitel 2 sind die geplanten Erweiterungspunkte in der Architekturdokumentation beschrieben.

## Technische Grundlage

| Baustein | Festgelegte Version |
|---|---|
| Pyodide / eingebettetes CPython | 314.0.8 / 3.14.2 |
| PGlite | 0.6.0 |
| CodeMirror | Version 6, SQL-Sprachpaket 6.10.0 |
| pgsql-ast-parser | 12.0.2 |
| Vite / Playwright Test | 8.4.0 / 1.65.1 |

Die App liefert ihre Abhängigkeiten lokal aus. Links zu W3Schools sind freiwillige Vertiefungen. Spielstände sind pro Browserprofil, Website und Installationspfad getrennt. Die Spielerdaten liegen in PostgreSQL auf IndexedDB. Der Export enthält Fortschritt, Pilot und Einstellungen sowie die Version des unveränderlichen Kapitel-1-Datensatzes. Die restliche Crew und der Lernverlauf sind daraus eindeutig rekonstruierbar. SQL-Entwürfe bleiben nur innerhalb der geöffneten Seite erhalten.

## Veröffentlichung und Zusammenarbeit

Eine vollständige Anleitung für ein neues GitHub-Repository, GitHub Pages, Pull Requests und die Arbeitsteilung steht in [Team und Veröffentlichung](docs/TEAM-UND-PAGES.md). Der fertige Build kann auch komplett auf einen anderen statischen HTTPS-Host kopiert werden.

## Grenzen und nächster Meilenstein

Kapitel 2 bis 8 sind geplante Kapitel. Kapitel 1 unterstützt eine einzelne lesende SELECT-Abfrage mit Spalten, Vergleichen und Filtern. Komplexere PostgreSQL-Ausdrücke können ausserhalb dieser Lernsprache liegen. Zwei Testdatenmengen erkennen viele zufällige Treffer, sind aber kein mathematischer Beweis für beliebige SQL-Abfragen. Pro Spielstand kann ein Tab gleichzeitig schreiben. Löschen der Browserdaten entfernt die lokale Datenbank.

Die beiden WASM-Laufzeiten benötigen auf schwächeren Geräten Zeit und Speicher. Messwerte und Testumfang stehen in [Tests](docs/TESTS.md) und [Prototyp](prototype/README.md). Als nächsten Schritt empfehlen wir einen kurzen Klassentest zur Verständlichkeit von Mission 7 und 10, danach die erste transaktionale INSERT-Mission mit nur einem Rezept.

Eigene Grafiken und Klänge, Paketlizenzen und Quellen sind in [Assets und Bibliotheken](docs/ASSETS.md) dokumentiert.

