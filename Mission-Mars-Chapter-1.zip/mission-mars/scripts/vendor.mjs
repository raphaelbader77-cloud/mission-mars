import { cp, mkdir, readdir } from "node:fs/promises";
import { join } from "node:path";

// Both runtimes resolve their WASM and data files relative to their JS entry.
const packages = [
  [
    "pyodide",
    "pyodide",
    /^(pyodide\.mjs|pyodide\.asm\.(wasm|mjs|js)|python_stdlib\.zip|pyodide-lock\.json)$/,
  ],
  [
    "@electric-sql/pglite/dist",
    "pglite",
    /^(index\.js|chunk-[\w-]+\.js|(?:initdb|pglite)\.(wasm|js|data))$/,
  ],
];
for (const [source, folder, include] of packages) {
  const from = join("node_modules", source);
  const to = join("public/vendor", folder);
  await mkdir(to, { recursive: true });
  for (const file of await readdir(from)) {
    if (include.test(file)) await cp(join(from, file), join(to, file));
  }
}
